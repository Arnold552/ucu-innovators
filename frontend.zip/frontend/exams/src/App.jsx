import { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { LandingPage } from './components/LandingPage';
import { LoginPage } from './components/LoginPage';
import { RegisterPage } from './components/RegisterPage';
import { StudentDashboard } from './components/StudentDashboard';
import { SupervisorDashboard } from './components/SupervisorDashboard';
import { AdminDashboard } from './components/AdminDashboard';
import { ProjectDetailPage } from './components/ProjectDetailPage';
import { ProtectedRoute } from './components/ProtectedRoute';

import './App.css';

// API base URL
const API_URL = import.meta.env.VITE_API_ckcoURL || 'http://localhost:5000/api';

function App() {
  const [user, setUser] = useState(null);
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);

  // Check for stored user and fetch projects
  useEffect(() => {
    const initializeApp = async () => {
      // Check for stored user
      const storedUser = localStorage.getItem('ucuUser');
      if (storedUser) {
        setUser(JSON.parse(storedUser));
      }

      // Fetch projects from backend
      await fetchProjects();
      setLoading(false);
    };

    initializeApp();
  }, []);

  const fetchProjects = async () => {
    try {
      const response = await fetch(`${API_URL}/projects`);
      if (response.ok) {
        const projectsData = await response.json();
        setProjects(projectsData);
      } else {
        console.error('Failed to fetch projects');
      }
    } catch (error) {
      console.error('Error fetching projects:', error);
    }
  };

  const handleLogin = async (loggedInUser) => {
    setUser(loggedInUser);
    localStorage.setItem('ucuUser', JSON.stringify(loggedInUser));
    await fetchProjects(); // Refresh projects after login
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem('ucuUser');
  };

  const handleRegister = async (newUser) => {
    setUser(newUser);
    localStorage.setItem('ucuUser', JSON.stringify(newUser));
    await fetchProjects(); // Refresh projects after registration
  };

  const handleProjectSubmit = async (project) => {
    try {
      const response = await fetch(`${API_URL}/projects`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${user?.token}`,
        },
        body: JSON.stringify(project),
      });

      if (response.ok) {
        await fetchProjects(); // Refresh projects list
      } else {
        console.error('Failed to submit project');
      }
    } catch (error) {
      console.error('Error submitting project:', error);
    }
  };

  const handleProjectUpdate = async (updatedProject) => {
    try {
      const response = await fetch(`${API_URL}/projects/${updatedProject.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${user?.token}`,
        },
        body: JSON.stringify(updatedProject),
      });

      if (response.ok) {
        await fetchProjects(); // Refresh projects list
      } else {
        console.error('Failed to update project');
      }
    } catch (error) {
      console.error('Error updating project:', error);
    }
  };

  const handleProjectReview = async (projectId, status, comments) => {
    try {
      const response = await fetch(`${API_URL}/projects/${projectId}/review`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${user?.token}`,
        },
        body: JSON.stringify({ status, comments, supervisorName: user?.name }),
      });

      if (response.ok) {
        await fetchProjects(); // Refresh projects list
      } else {
        console.error('Failed to review project');
      }
    } catch (error) {
      console.error('Error reviewing project:', error);
    }
  };

  const handleAddComment = async (projectId, content) => {
    if (!user) return;

    try {
      const response = await fetch(`${API_URL}/projects/${projectId}/comments`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${user?.token}`,
        },
        body: JSON.stringify({
          content,
          userId: user.id,
          userName: user.name,
          userRole: user.role,
        }),
      });

      if (response.ok) {
        await fetchProjects(); // Refresh projects to get updated comments
      } else {
        console.error('Failed to add comment');
      }
    } catch (error) {
      console.error('Error adding comment:', error);
    }
  };

  if (loading) {
    return (
      <div className="loading-container">
        <div className="loading-spinner">Loading...</div>
      </div>
    );
  }

  return (
    <Router>
      <Routes>
        <Route path="/" element={<LandingPage user={user} onLogout={handleLogout} projects={projects} />} />
        <Route path="/login" element={user ? <Navigate to={`/${user.role}`} /> : <LoginPage onLogin={handleLogin} />} />
        <Route path="/register" element={user ? <Navigate to={`/${user.role}`} /> : <RegisterPage onRegister={handleRegister} />} />
        <Route path="/project/:id" element={<ProjectDetailPage user={user} onLogout={handleLogout} projects={projects} onAddComment={handleAddComment} onUpdateProject={handleProjectUpdate} />} />
        
        <Route
          path="/student"
          element={
            <ProtectedRoute user={user} allowedRoles={['student']}>
              <StudentDashboard user={user} onLogout={handleLogout} projects={projects} onProjectSubmit={handleProjectSubmit} />
            </ProtectedRoute>
          }
        />
        
        <Route
          path="/supervisor"
          element={
            <ProtectedRoute user={user} allowedRoles={['supervisor']}>
              <SupervisorDashboard user={user} onLogout={handleLogout} projects={projects} onProjectReview={handleProjectReview} />
            </ProtectedRoute>
          }
        />
        
        <Route
          path="/admin"
          element={
            <ProtectedRoute user={user} allowedRoles={['admin']}>
              <AdminDashboard user={user} onLogout={handleLogout} projects={projects} />
            </ProtectedRoute>
          }
        />
      </Routes>
    </Router>
  );
}

export default App;