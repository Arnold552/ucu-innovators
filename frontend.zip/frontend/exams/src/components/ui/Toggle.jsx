import * as React from "react";
import * as TogglePrimitive from "@radix-ui/react-toggle@1.1.2";

import { cn } from "./utils";
import "./Toggle.css";

function Toggle({
  className,
  variant = "default",
  size = "default",
  ...props
}) {
  return (
    <TogglePrimitive.Root
      data-slot="toggle"
      className={cn(
        "toggle",
        `toggle-${variant}`,
        `toggle-${size}`,
        className
      )}
      {...props}
    />
  );
}

export { Toggle };