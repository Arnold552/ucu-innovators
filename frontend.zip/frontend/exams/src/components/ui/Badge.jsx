import * as React from "react";
import { Slot } from "@radix-ui/react-slot";
import { cn } from "./utils";
import "./Badge.css";

function Badge({
  className,
  variant = "default",
  asChild = false,
  ...props
}) {
  const Comp = asChild ? Slot : "span";

  const badgeClass = cn(
    "badge",
    `badge-${variant}`,
    className
  );

  return (
    <Comp
      data-slot="badge"
      className={badgeClass}
      {...props}
    />
  );
}

export { Badge };