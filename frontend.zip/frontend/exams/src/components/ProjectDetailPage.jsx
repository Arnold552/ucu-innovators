import { useState } from 'react';
import { Link, useParams, useNavigate } from 'react-router-dom';
import { Lightbulb, LogOut, ArrowLeft, Github, FileText, Calendar, User as UserIcon, Eye, Heart, MessageSquare, Send, CheckCircle, XCircle, Clock } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import './ProjectDetailPage.css';

export function ProjectDetailPage({ user, onLogout, projects, onAddComment, onUpdateProject }) {
  const { id } = useParams();
  const navigate = useNavigate();
  const [commentText, setCommentText] = useState('');

  const project = projects.find(p => p.id === id);

  if (!project) {
    return (
      <div className="project-not-found">
        <div className="not-found-content">
          <p className="not-found-text">Project not found</p>
          <Link to="/" className="back-home-link">
            ← Back to Home
          </Link>
        </div>
      </div>
    );
  }

  // Increment view count on load (only once per session)
  const hasViewed = sessionStorage.getItem(`viewed_${project.id}`);
  if (!hasViewed && project.status === 'approved') {
    sessionStorage.setItem(`viewed_${project.id}`, 'true');
    onUpdateProject({ ...project, views: project.views + 1 });
  }

  const handleLike = () => {
    onUpdateProject({ ...project, likes: project.likes + 1 });
  };

  const handleCommentSubmit = (e) => {
    e.preventDefault();
    if (!user) {
      navigate('/login');
      return;
    }
    if (commentText.trim()) {
      onAddComment(project.id, commentText);
      setCommentText('');
    }
  };

  const getStatusIcon = () => {
    switch (project.status) {
      case 'approved':
        return <CheckCircle className="status-icon approved" />;
      case 'rejected':
        return <XCircle className="status-icon rejected" />;
      case 'pending':
        return <Clock className="status-icon pending" />;
    }
  };

  const getStatusBadgeClass = () => {
    switch (project.status) {
      case 'approved':
        return 'status-badge approved';
      case 'rejected':
        return 'status-badge rejected';
      case 'pending':
        return 'status-badge pending';
    }
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
  };

  return (
    <div className="project-detail-page">
      {/* Header */}
      <header className="project-detail-header">
        <div className="header-container">
          <Link to="/" className="logo-link">
            <div className="logo-icon">
              <Lightbulb className="logo-svg" />
            </div>
            <div className="logo-text">
              <h1 className="logo-title">UCU Innovators Hub</h1>
            </div>
          </Link>
          <div className="header-actions">
            {user && (
              <>
                <Link
                  to={`/${user.role}`}
                  className="dashboard-link"
                >
                  Dashboard
                </Link>
                <button
                  onClick={onLogout}
                  className="logout-btn"
                >
                  <LogOut className="logout-icon" />
                  <span className="logout-text">Logout</span>
                </button>
              </>
            )}
          </div>
        </div>
      </header>

      <div className="project-detail-container">
        {/* Back Button */}
        <button
          onClick={() => navigate(-1)}
          className="back-button"
        >
          <ArrowLeft className="back-icon" />
          Back
        </button>

        {/* Project Header */}
        <div className="project-detail-card">
          <div className="project-header">
            <div className="project-title-section">
              <div className="status-section">
                {getStatusIcon()}
                <span className={getStatusBadgeClass()}>
                  {project.status.charAt(0).toUpperCase() + project.status.slice(1)}
                </span>
              </div>
              <h2 className="project-title">{project.title}</h2>
              <div className="project-tags">
                <span className="category-tag">
                  {project.category}
                </span>
                <span className="faculty-tag">
                  {project.faculty}
                </span>
              </div>
            </div>
          </div>

          {/* Project Image */}
          {project.imageUrl && (
            <div className="project-image-wrapper">
              <ImageWithFallback
                src={project.imageUrl}
                alt={project.title}
                className="project-main-image"
              />
            </div>
          )}

          {/* Description */}
          <div className="description-section">
            <h3 className="section-title">About this Project</h3>
            <p className="description-text">{project.description}</p>
          </div>

          {/* Technologies */}
          <div className="technologies-section">
            <h3 className="section-title">Technologies Used</h3>
            <div className="technologies-list">
              {project.technologies.map((tech, index) => (
                <span key={index} className="technology-tag">
                  {tech}
                </span>
              ))}
            </div>
          </div>

          {/* Project Info */}
          <div className="project-info-grid">
            <div className="info-item">
              <UserIcon className="info-icon" />
              <div className="info-content">
                <p className="info-label">Student</p>
                <p className="info-value">{project.submittedByName}</p>
              </div>
            </div>
            {project.supervisorName && (
              <div className="info-item">
                <UserIcon className="info-icon" />
                <div className="info-content">
                  <p className="info-label">Supervisor</p>
                  <p className="info-value">{project.supervisorName}</p>
                </div>
              </div>
            )}
            <div className="info-item">
              <Calendar className="info-icon" />
              <div className="info-content">
                <p className="info-label">Submitted</p>
                <p className="info-value">{formatDate(project.submittedDate)}</p>
              </div>
            </div>
            <div className="info-item">
              <Calendar className="info-icon" />
              <div className="info-content">
                <p className="info-label">Year</p>
                <p className="info-value">{project.year}</p>
              </div>
            </div>
          </div>

          {/* Links */}
          <div className="project-links">
            {project.githubLink && (
              <a
                href={project.githubLink}
                target="_blank"
                rel="noopener noreferrer"
                className="project-link github-link"
              >
                <Github className="link-icon" />
                View on GitHub
              </a>
            )}
            {project.pdfLink && (
              <a
                href={project.pdfLink}
                target="_blank"
                rel="noopener noreferrer"
                className="project-link doc-link"
              >
                <FileText className="link-icon" />
                View Documentation
              </a>
            )}
          </div>

          {/* Engagement */}
          {project.status === 'approved' && (
            <div className="engagement-section">
              <div className="engagement-item">
                <Eye className="engagement-icon" />
                <span className="engagement-text">{project.views} views</span>
              </div>
              <button
                onClick={handleLike}
                className="engagement-item like-button"
              >
                <Heart className="engagement-icon" />
                <span className="engagement-text">{project.likes}</span>
              </button>
              <div className="engagement-item">
                <MessageSquare className="engagement-icon" />
                <span className="engagement-text">{project.comments.length} comments</span>
              </div>
            </div>
          )}

          {/* Review Comments */}
          {project.reviewComments && (
            <div className="review-comments">
              <h4 className="review-title">Supervisor Feedback</h4>
              <p className="review-text">{project.reviewComments}</p>
              {project.supervisorName && (
                <p className="review-author">— {project.supervisorName}</p>
              )}
            </div>
          )}
        </div>

        {/* Comments Section */}
        {project.status === 'approved' && (
          <div className="comments-section">
            <h3 className="comments-title">Comments ({project.comments.length})</h3>

            {/* Comment Form */}
            <form onSubmit={handleCommentSubmit} className="comment-form">
              <div className="comment-input-group">
                <div className="comment-input-container">
                  <textarea
                    value={commentText}
                    onChange={(e) => setCommentText(e.target.value)}
                    placeholder={user ? "Share your thoughts..." : "Please login to comment"}
                    disabled={!user}
                    rows={3}
                    className="comment-textarea"
                  />
                </div>
                <button
                  type="submit"
                  disabled={!user || !commentText.trim()}
                  className="comment-submit-btn"
                >
                  <Send className="submit-icon" />
                </button>
              </div>
              {!user && (
                <p className="login-prompt">
                  <Link to="/login" className="login-link">Login</Link> to leave a comment
                </p>
              )}
            </form>

            {/* Comments List */}
            {project.comments.length === 0 ? (
              <p className="no-comments">No comments yet. Be the first to comment!</p>
            ) : (
              <div className="comments-list">
                {project.comments
                  .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                  .map(comment => (
                    <div key={comment.id} className="comment-item">
                      <div className="comment-content">
                        <div className="comment-avatar">
                          <span className="avatar-text">
                            {comment.userName.charAt(0).toUpperCase()}
                          </span>
                        </div>
                        <div className="comment-body">
                          <div className="comment-header">
                            <span className="comment-author">{comment.userName}</span>
                            <span className="comment-role">
                              {comment.userRole}
                            </span>
                            <span className="comment-date">
                              {new Date(comment.date).toLocaleDateString()}
                            </span>
                          </div>
                          <p className="comment-text">{comment.content}</p>
                        </div>
                      </div>
                    </div>
                  ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}