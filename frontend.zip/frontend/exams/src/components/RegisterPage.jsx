import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Lightbulb, Mail, Lock, User as UserIcon, Building, BookOpen, AlertCircle, CheckCircle } from 'lucide-react';
import './RegisterPage.css';

// API base URL
const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

export function RegisterPage({ onRegister }) {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: '',
    role: 'student',
    faculty: '',
    department: ''
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const faculties = [
    'Science and Technology',
    'Engineering',
    'Business and Administration',
    'Social Sciences',
    'Law',
    'Theology',
    'Education'
  ];

  const departments = [
    'Computer Science',
    'Information Technology',
    'Software Engineering',
    'Data Science',
    'Electrical Engineering',
    'Civil Engineering',
    'Business Administration',
    'Accounting',
    'Psychology',
    'Social Work'
  ];

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    // Validation
    if (!formData.name || !formData.email || !formData.password || !formData.confirmPassword) {
      setError('Please fill in all required fields');
      setLoading(false);
      return;
    }

    if (!formData.email.endsWith('@ucu.ac.ug')) {
      setError('Please use your UCU email address');
      setLoading(false);
      return;
    }

    if (formData.password.length < 6) {
      setError('Password must be at least 6 characters');
      setLoading(false);
      return;
    }

    if (formData.password !== formData.confirmPassword) {
      setError('Passwords do not match');
      setLoading(false);
      return;
    }

    if ((formData.role === 'student' || formData.role === 'supervisor') && (!formData.faculty || !formData.department)) {
      setError('Please select faculty and department');
      setLoading(false);
      return;
    }

    try {
      // Send registration data to backend
      const response = await fetch(`${API_URL}/auth/register`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          name: formData.name,
          email: formData.email,
          password: formData.password,
          role: formData.role,
          faculty: formData.faculty,
          department: formData.department
        }),
      });

      const data = await response.json();

      if (response.ok) {
        // Call the onRegister callback with user data
        onRegister(data.user);
        navigate(`/${data.user.role}`);
      } else {
        setError(data.error || 'Registration failed');
      }
    } catch (error) {
      console.error('Registration error:', error);
      setError('Network error. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="register-page">
      <div className="register-container">
        {/* Logo */}
        <div className="register-header">
          <div className="logo-banner">
            <div className="logo-icon">
              <Lightbulb className="logo-svg" />
            </div>
            <div className="logo-text">
              <h1 className="logo-title">UCU Innovators Hub</h1>
            </div>
          </div>
          <p className="register-subtitle">Create your account to start sharing innovations.</p>
        </div>

        {/* Registration Form */}
        <div className="register-card">
          <h2 className="register-title">Register</h2>

          {error && (
            <div className="error-message">
              <AlertCircle className="error-icon" />
              <span className="error-text">{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="register-form">
            {/* Name */}
            <div className="form-group">
              <label className="form-label">Full Name *</label>
              <div className="input-container">
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  placeholder="Your full name"
                  className="form-input"
                  required
                />
              </div>
            </div>

            {/* Email */}
            <div className="form-group">
              <label className="form-label">UCU Email Address *</label>
              <div className="input-container">
                <input
                  
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  placeholder="your.name@ucu.ac.ug"
                  className="form-input"
                  required
                />
              </div>
            </div>

            {/* Role Selection */}
            <div className="form-group">
              <label className="form-label">I am a *</label>
              <div className="role-selection">
                <button
                  type="button"
                  onClick={() => setFormData({ ...formData, role: 'student' })}
                  className={`role-button ${formData.role === 'student' ? 'selected' : ''}`}
                >
                  <div className="role-content">
                    <CheckCircle className={`role-check ${formData.role === 'student' ? 'selected' : ''}`} />
                    <span className="role-text">Student</span>
                  </div>
                </button>
                <button
                  type="button"
                  onClick={() => setFormData({ ...formData, role: 'supervisor' })}
                  className={`role-button ${formData.role === 'supervisor' ? 'selected' : ''}`}
                >
                  <div className="role-content">
                    <CheckCircle className={`role-check ${formData.role === 'supervisor' ? 'selected' : ''}`} />
                    <span className="role-text">Supervisor</span>
                  </div>
                </button>
                <button
                  type="button"
                  onClick={() => setFormData({ ...formData, role: 'admin' })}
                  className={`role-button ${formData.role === 'admin' ? 'selected' : ''}`}
                >
                  <div className="role-content">
                    <CheckCircle className={`role-check ${formData.role === 'admin' ? 'selected' : ''}`} />
                    <span className="role-text">Admin</span>
                  </div>
                </button>
              </div>
            </div>

            {/* Faculty and Department (only for students and supervisors) */}
            {formData.role !== 'admin' && (
              <div className="form-grid">
                <div className="form-group">
                  <label className="form-label">Faculty *</label>
                  <div className="input-container">
                    <select
                      name="faculty"
                      value={formData.faculty}
                      onChange={handleChange}
                      className="form-select"
                      required
                    >
                      <option value="">Select Faculty</option>
                      {faculties.map(faculty => (
                        <option key={faculty} value={faculty}>{faculty}</option>
                      ))}
                    </select>
                  </div>
                </div>
                <div className="form-group">
                  <label className="form-label">Department *</label>
                  <div className="input-container">
                    <select
                      name="department"
                      value={formData.department}
                      onChange={handleChange}
                      className="form-select"
                      required
                    >
                      <option value="">Select Department</option>
                      {departments.map(dept => (
                        <option key={dept} value={dept}>{dept}</option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>
            )}

            {/* Password */}
            <div className="form-grid">
              <div className="form-group">
                <label className="form-label">Password *</label>
                <div className="input-container">
                  <input
                    type="password"
                    name="password"
                    value={formData.password}
                    onChange={handleChange}
                    placeholder="Min. 6 characters"
                    className="form-input"
                    required
                    minLength="6"
                  />
                </div>
              </div>
              <div className="form-group">
                <label className="form-label">Confirm Password *</label>
                <div className="input-container">
                  <input
                    type="password"
                    name="confirmPassword"
                    value={formData.confirmPassword}
                    onChange={handleChange}
                    placeholder="Confirm password"
                    className="form-input"
                    required
                  />
                </div>
              </div>
            </div>

            <button
              type="submit"
              className="register-button"
              disabled={loading}
            >
              {loading ? 'Creating Account...' : 'Create Account'}
            </button>
          </form>

          <div className="register-footer">
            <p className="login-text">
              Already have an account?{' '}
              <Link to="/login" className="login-link">
                Login here
              </Link>
            </p>
          </div>
        </div>

        <div className="back-link-container">
          <Link to="/" className="back-link">
            ← Back to Home
          </Link>
        </div>
      </div>
    </div>
  );
}