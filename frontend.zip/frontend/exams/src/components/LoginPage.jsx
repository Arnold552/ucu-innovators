import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Lightbulb, Mail, Lock, AlertCircle, Loader } from 'lucide-react';
import './LoginPage.css';

// API base URL
const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

export function LoginPage({ onLogin }) {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    // Validation
    if (!email || !password) {
      setError('Please fill in all fields');
      setLoading(false);
      return;
    }

    try {
      console.log('Sending login request for:', email);

      const response = await fetch(`${API_URL}/auth/login`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          email: email.toLowerCase(),
          password: password
        }),
      });

      console.log('Response status:', response.status);
      
      const data = await response.json();
      console.log('Response data:', data);

      if (response.ok) {
        // Store user data and token
        localStorage.setItem('ucuUser', JSON.stringify(data.user));
        localStorage.setItem('ucuToken', data.token);
        
        // Call the parent handler
        onLogin(data.user);
        navigate(`/${data.user.role}`);
      } else {
        setError(data.error || 'Invalid email or password');
      }
    } catch (error) {
      console.error('Login error:', error);
      setError('Network error. Please check if the server is running.');
    } finally {
      setLoading(false);
    }
  };

  // Demo accounts helper function
  const fillDemoAccount = (accountType) => {
    const demoAccounts = {
      student: {
        email: 'student@ucu.ac.ug',
        password: 'student123'
      },
      supervisor: {
        email: 'supervisor@ucu.ac.ug',
        password: 'supervisor123'
      },
      admin: {
        email: 'admin@ucu.ac.ug',
        password: 'admin123'
      }
    };

    const account = demoAccounts[accountType];
    if (account) {
      setEmail(account.email);
      setPassword(account.password);
    }
  };

  return (
    <div className="login-page">
      <div className="login-container">
        {/* Logo */}
        <div className="login-header">
          <div className="logo-banner">
            <div className="logo-icon">
              <Lightbulb className="logo-svg" />
            </div>
            <div className="logo-text">
              <h1 className="logo-title">UCU Innovators Hub</h1>
            </div>
          </div>
          <p className="login-subtitle">Welcome back! Please login to continue.</p>
        </div>

        {/* Login Form */}
        <div className="login-card">
          <h2 className="login-title">Login</h2>

          {error && (
            <div className="error-message">
              <AlertCircle className="error-icon" />
              <span className="error-text">{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="login-form">
            <div className="form-group">
              <label className="form-label">Email Address</label>
              <div className="input-container">
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="your.email@ucu.ac.ug"
                  className="form-input"
                  disabled={loading}
                  required
                />
              </div>
            </div>

            <div className="form-group">
              <label className="form-label">Password</label>
              <div className="input-container">
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter your password"
                  className="form-input"
                  disabled={loading}
                  required
                />
              </div>
            </div>

            <button
              type="submit"
              className={`login-button ${loading ? 'loading' : ''}`}
              disabled={loading}
            >
              {loading ? (
                <>
                  <Loader className="button-loader" />
                  Logging in...
                </>
              ) : (
                'Login'
              )}
            </button>
          </form>

          <div className="login-footer">
            <p className="register-text">
              Don't have an account?{' '}
              <Link to="/register" className="register-link">
                Register here
              </Link>
            </p>
          </div>
        </div>

        <div className="back-link-container">
          <Link to="/" className="back-link">
            ← Back to Home
          </Link>
        </div>
      </div>
    </div>
  );
}