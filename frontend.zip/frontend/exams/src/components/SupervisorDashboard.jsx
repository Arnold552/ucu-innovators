import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Lightbulb, LogOut, CheckCircle, XCircle, Clock, MessageSquare, Filter, Loader } from 'lucide-react';
import './SupervisorDashboard.css';

// API base URL
const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

export function SupervisorDashboard({ user, onLogout }) {
  const [selectedProject, setSelectedProject] = useState(null);
  const [reviewStatus, setReviewStatus] = useState('approved');
  const [reviewComments, setReviewComments] = useState('');
  const [filterStatus, setFilterStatus] = useState('pending');
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [reviewLoading, setReviewLoading] = useState(false);
  const [error, setError] = useState('');

  // Fetch projects from backend
  useEffect(() => {
    fetchSupervisorProjects();
  }, []);

  const fetchSupervisorProjects = async () => {
  try {
    setLoading(true);
    setError('');
    
    console.log('=== FETCHING SUPERVISOR PROJECTS ===');
    
    const token = localStorage.getItem('ucuToken');
    console.log('Token exists:', !!token);
    console.log('User data:', user);
    
    if (!token) {
      console.error('No token found in localStorage');
      throw new Error('No authentication token found');
    }

    // Test the API endpoint first
    console.log('Testing API endpoint...');
    const testResponse = await fetch(`${API_URL}/health`);
    console.log('Health check status:', testResponse.status);
    
    if (!testResponse.ok) {
      console.error('Backend not reachable');
      throw new Error('Backend server is not responding');
    }

    console.log(`Fetching from: ${API_URL}/projects/supervisor`);
    
    const response = await fetch(`${API_URL}/projects/supervisor`, {
      headers: {
        'Authorization': `Bearer ${token}`,
      },
    });

    console.log('Response status:', response.status);
    console.log('Response headers:', Object.fromEntries(response.headers.entries()));
    
    if (!response.ok) {
      if (response.status === 401) {
        console.error('Token invalid or expired');
        localStorage.removeItem('ucuToken');
        window.location.href = '/login';
        return;
      }
      
      if (response.status === 404) {
        console.error('Endpoint not found');
        throw new Error('Supervisor endpoint not found on server');
      }
      
      // Try to get error details from response
      let errorMessage = `HTTP ${response.status}: Failed to fetch projects`;
      try {
        const errorData = await response.json();
        console.error('Error response data:', errorData);
        errorMessage = errorData.error || errorData.message || errorMessage;
      } catch (e) {
        console.error('Could not parse error response:', e);
      }
      
      throw new Error(errorMessage);
    }

    const data = await response.json();
    console.log('Received data:', data);
    console.log('Number of projects:', data.projects?.length || 0);
    
    setProjects(data.projects || []);
    
  } catch (error) {
    console.error('Error fetching projects:', error);
    console.error('Error stack:', error.stack);
    
    // More specific error messages
    if (error.message.includes('Failed to fetch')) {
      setError('Network error: Cannot connect to server. Check if backend is running.');
    } else if (error.message.includes('404')) {
      setError('API endpoint not found. Check backend routes.');
    } else if (error.message.includes('401')) {
      setError('Session expired. Please login again.');
    } else {
      setError(error.message || 'Failed to fetch projects');
    }
  } finally {
    setLoading(false);
  }
};

  // Filter projects by faculty
  const relevantProjects = projects.filter(p => 
    p.faculty_id === user.faculty_id || p.faculty === user.faculty
  );

  const filteredProjects = relevantProjects.filter(p => 
    filterStatus === 'all' || p.status === filterStatus
  );

  const pendingCount = relevantProjects.filter(p => p.status === 'pending').length;
  const approvedCount = relevantProjects.filter(p => p.status === 'approved').length;
  const rejectedCount = relevantProjects.filter(p => p.status === 'rejected').length;

  const handleReview = async (e) => {
    e.preventDefault();
    if (!selectedProject) return;

    try {
      setReviewLoading(true);
      
      const token = localStorage.getItem('ucuToken');
      if (!token) {
        alert('Session expired. Please login again.');
        localStorage.removeItem('ucuToken');
        window.location.href = '/login';
        return;
      }

      const response = await fetch(`${API_URL}/projects/${selectedProject.id}/status`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({
          status: reviewStatus,
          feedback: reviewComments
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to submit review');
      }

      alert(`Project ${reviewStatus} successfully!`);
      
      // Update local state
      const updatedProjects = projects.map(p => 
        p.id === selectedProject.id 
          ? { 
              ...p, 
              status: reviewStatus, 
              feedback: reviewComments,
              supervisor_id: user.id,
              supervisor_name: user.name,
              updated_at: new Date().toISOString()
            }
          : p
      );
      
      setProjects(updatedProjects);
      
      // Reset form
      setSelectedProject(null);
      setReviewComments('');
      setReviewStatus('approved');
      
    } catch (error) {
      console.error('Error submitting review:', error);
      alert(error.message || 'Failed to submit review. Please try again.');
    } finally {
      setReviewLoading(false);
    }
  };

  const getStatusBadgeClass = (status) => {
    switch (status) {
      case 'pending':
        return 'status-badge pending';
      case 'approved':
        return 'status-badge approved';
      case 'rejected':
        return 'status-badge rejected';
      default:
        return 'status-badge default';
    }
  };

  const getStatusText = (status) => {
    if (!status) return 'Unknown';
    return status.charAt(0).toUpperCase() + status.slice(1);
  };

  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  if (loading) {
    return (
      <div className="supervisor-dashboard">
        <header className="dashboard-header">
          <div className="header-container">
            <Link to="/" className="logo-link">
              <div className="logo-icon">
                <Lightbulb className="logo-svg" />
              </div>
              <div className="logo-text">
                <h1 className="logo-title">UCU Innovators Hub</h1>
                <p className="logo-subtitle">Supervisor Dashboard</p>
              </div>
            </Link>
          </div>
        </header>
        <div className="loading-container">
          <Loader className="loading-spinner" />
          <p>Loading projects...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="supervisor-dashboard">
      {/* Header */}
      <header className="dashboard-header">
        <div className="header-container">
          <Link to="/" className="logo-link">
            <div className="logo-icon">
              <Lightbulb className="logo-svg" />
            </div>
            <div className="logo-text">
              <h1 className="logo-title">UCU Innovators Hub</h1>
              <p className="logo-subtitle">Supervisor Dashboard</p>
            </div>
          </Link>
          <div className="header-actions">
            <div className="user-info">
              <p className="user-name">{user.name}</p>
              <p className="user-department">{user.department || user.faculty_name}</p>
            </div>
            <button
              onClick={onLogout}
              className="logout-btn"
            >
              <LogOut className="logout-icon" />
              <span className="logout-text">Logout</span>
            </button>
          </div>
        </div>
      </header>

      <div className="dashboard-container">
        {/* Welcome Section */}
        <div className="welcome-section">
          <h2 className="welcome-title">Welcome, {user.name}</h2>
          <p className="welcome-subtitle">
            Review and approve student project submissions from your faculty.
          </p>
          {error && <p className="error-message">{error}</p>}
        </div>

        {/* Stats */}
        <div className="stats-grid">
          <div className="stat-card">
            <div className="stat-content">
              <div className="stat-icon pending">
                <Clock className="stat-icon-svg" />
              </div>
              <div className="stat-text">
                <p className="stat-value">{pendingCount}</p>
                <p className="stat-label">Pending Review</p>
              </div>
            </div>
          </div>
          <div className="stat-card">
            <div className="stat-content">
              <div className="stat-icon approved">
                <CheckCircle className="stat-icon-svg" />
              </div>
              <div className="stat-text">
                <p className="stat-value">{approvedCount}</p>
                <p className="stat-label">Approved</p>
              </div>
            </div>
          </div>
          <div className="stat-card">
            <div className="stat-content">
              <div className="stat-icon rejected">
                <XCircle className="stat-icon-svg" />
              </div>
              <div className="stat-text">
                <p className="stat-value">{rejectedCount}</p>
                <p className="stat-label">Rejected</p>
              </div>
            </div>
          </div>
        </div>

        {/* Filter */}
        <div className="filter-section">
          <div className="filter-content">
            <Filter className="filter-icon" />
            <div className="filter-buttons">
              <button
                onClick={() => setFilterStatus('pending')}
                className={`filter-btn ${filterStatus === 'pending' ? 'active' : ''}`}
              >
                Pending ({pendingCount})
              </button>
              <button
                onClick={() => setFilterStatus('approved')}
                className={`filter-btn ${filterStatus === 'approved' ? 'active' : ''}`}
              >
                Approved ({approvedCount})
              </button>
              <button
                onClick={() => setFilterStatus('rejected')}
                className={`filter-btn ${filterStatus === 'rejected' ? 'active' : ''}`}
              >
                Rejected ({rejectedCount})
              </button>
              <button
                onClick={() => setFilterStatus('all')}
                className={`filter-btn ${filterStatus === 'all' ? 'active' : ''}`}
              >
                All ({relevantProjects.length})
              </button>
            </div>
          </div>
        </div>

        {/* Projects List */}
        <div className="projects-section">
          <h3 className="section-title">
            {filterStatus === 'all' ? 'All Projects' : `${getStatusText(filterStatus)} Projects`}
            ({filteredProjects.length})
          </h3>
          
          {filteredProjects.length === 0 ? (
            <div className="empty-projects">
              <p className="empty-text">
                {filterStatus === 'pending' 
                  ? 'No pending projects to review.' 
                  : 'No projects found.'}
              </p>
              <button
                onClick={fetchSupervisorProjects}
                className="refresh-btn"
              >
                Refresh
              </button>
            </div>
          ) : (
            <div className="projects-list">
              {filteredProjects.map(project => (
                <div key={project.id} className="project-item">
                  <div className="project-content">
                    <div className="project-header">
                      <div className="project-title-section">
                        <Link to={`/project/${project.id}`} className="project-link">
                          <h4 className="project-title">{project.title}</h4>
                        </Link>
                        <span className={getStatusBadgeClass(project.status)}>
                          {getStatusText(project.status)}
                        </span>
                      </div>
                    </div>
                    <p className="project-meta">
                      By: {project.student_name || project.submittedByName} • 
                      Category: {project.category_name || project.category}
                    </p>
                    <p className="project-description">
                      {project.description.length > 150 
                        ? `${project.description.substring(0, 150)}...` 
                        : project.description}
                    </p>
                    
                    <div className="technologies-list">
                      {Array.isArray(project.technologies) 
                        ? project.technologies.slice(0, 5).map((tech, index) => (
                            <span key={index} className="tech-tag">
                              {tech}
                            </span>
                          ))
                        : JSON.parse(project.technologies || '[]').slice(0, 5).map((tech, index) => (
                            <span key={index} className="tech-tag">
                              {tech}
                            </span>
                          ))}
                    </div>

                    <div className="project-dates">
                      Submitted: {formatDate(project.created_at)}
                      {project.updated_at && project.status !== 'pending' && (
                        ` • Reviewed: ${formatDate(project.updated_at)}`
                      )}
                    </div>

                    {project.github_link && (
                      <a
                        href={project.github_link}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="github-link"
                      >
                        View GitHub Repository →
                      </a>
                    )}

                    {project.feedback && (
                      <div className="feedback-section">
                        <p className="feedback-text">
                          <strong>Review Feedback:</strong> {project.feedback}
                        </p>
                        {project.supervisor_name && (
                          <p className="feedback-author">— {project.supervisor_name}</p>
                        )}
                      </div>
                    )}
                  </div>

                  {project.status === 'pending' && (
                    <div className="review-actions">
                      <button
                        onClick={() => setSelectedProject(project)}
                        className="review-btn"
                      >
                        <MessageSquare className="btn-icon" />
                        Review Project
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Review Modal */}
      {selectedProject && (
        <div className="review-modal">
          <div className="modal-overlay">
            <div className="modal-content">
              <h3 className="modal-title">Review Project</h3>
              
              <div className="project-preview">
                <h4 className="project-preview-title">{selectedProject.title}</h4>
                <p className="project-preview-meta">
                  By: {selectedProject.student_name || selectedProject.submittedByName}
                </p>
                <p className="project-preview-description">{selectedProject.description}</p>
                
                {selectedProject.github_link && (
                  <a
                    href={selectedProject.github_link}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="preview-link"
                  >
                    View GitHub Repository
                  </a>
                )}
                
                {selectedProject.demo_link && (
                  <a
                    href={selectedProject.demo_link}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="preview-link"
                  >
                    View Live Demo
                  </a>
                )}
              </div>

              <form onSubmit={handleReview} className="review-form">
                <div className="form-group">
                  <label className="form-label">Review Decision</label>
                  <div className="decision-buttons">
                    <button
                      type="button"
                      onClick={() => setReviewStatus('approved')}
                      className={`decision-btn ${reviewStatus === 'approved' ? 'approved active' : ''}`}
                      disabled={reviewLoading}
                    >
                      <CheckCircle className={`decision-icon ${reviewStatus === 'approved' ? 'approved' : ''}`} />
                      <span className="decision-text">Approve</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setReviewStatus('rejected')}
                      className={`decision-btn ${reviewStatus === 'rejected' ? 'rejected active' : ''}`}
                      disabled={reviewLoading}
                    >
                      <XCircle className={`decision-icon ${reviewStatus === 'rejected' ? 'rejected' : ''}`} />
                      <span className="decision-text">Reject</span>
                    </button>
                  </div>
                </div>

                <div className="form-group">
                  <label className="form-label">Comments/Feedback (Required)</label>
                  <textarea
                    value={reviewComments}
                    onChange={(e) => setReviewComments(e.target.value)}
                    required
                    rows={4}
                    placeholder="Provide constructive feedback to the student about their project..."
                    className="form-textarea"
                    disabled={reviewLoading}
                  />
                </div>

                <div className="form-actions">
                  <button
                    type="submit"
                    className="btn-primary"
                    disabled={reviewLoading}
                  >
                    {reviewLoading ? (
                      <>
                        <Loader className="button-loader" />
                        Submitting...
                      </>
                    ) : (
                      'Submit Review'
                    )}
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedProject(null);
                      setReviewComments('');
                    }}
                    className="btn-secondary"
                    disabled={reviewLoading}
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}