import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Lightbulb, LogOut, Plus, Eye, Clock, CheckCircle, XCircle, Upload, Link as LinkIcon, FileText, Loader, Image as ImageIcon } from 'lucide-react';
import './StudentDashboard.css';

// API base URL
const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

export function StudentDashboard({ user, onLogout, projects, onProjectSubmit }) {
  const [showSubmitForm, setShowSubmitForm] = useState(false);
  const [loading, setLoading] = useState(false);
  const [userProjects, setUserProjects] = useState([]);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    category: '',
    technologies: '',
    github_link: '',
    demo_link: '',
    document_path: ''
  });

  // Fetch user's projects from backend
  useEffect(() => {
    const fetchUserProjects = async () => {
      try {
        const token = localStorage.getItem('ucuToken');
        const response = await fetch(`${API_URL}/projects/my-projects`, {
          headers: {
            'Authorization': `Bearer ${token}`,
          },
        });

        if (response.ok) {
          const data = await response.json();
          setUserProjects(data);
        } else {
          console.error('Failed to fetch user projects');
        }
      } catch (error) {
        console.error('Error fetching user projects:', error);
      }
    };

    if (user) {
      fetchUserProjects();
    }
  }, [user, projects]);

  const pendingCount = userProjects.filter(p => p.status === 'pending').length;
  const approvedCount = userProjects.filter(p => p.status === 'approved').length;
  const rejectedCount = userProjects.filter(p => p.status === 'rejected').length;

  const categories = [
    'Web Application',
    'Mobile Application',
    'Data Science',
    'Machine Learning',
    'IoT',
    'Blockchain',
    'Game Development',
    'Other'
  ];

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
  e.preventDefault();
  setLoading(true);

  try {
    const token = localStorage.getItem('ucuToken');
    console.log('Token from localStorage:', token ? 'Exists' : 'Missing');

    // Debug: Check if token is valid
    if (!token) {
      alert('No authentication token found. Please login again.');
      localStorage.removeItem('ucuToken');
      window.location.href = '/login';
      return;
    }

    // Category mapping - this should match your database categories
    const categoryMap = {
      'Web Application': 1,
      'Mobile Application': 2,
      'Data Science': 3,
      'Machine Learning': 4,
      'IoT': 5,
      'Blockchain': 6,
      'Game Development': 7,
      'Other': 8
    };

    const category_id = categoryMap[formData.category];
    if (!category_id) {
      alert('Please select a valid category');
      setLoading(false);
      return;
    }

    const projectData = {
      title: formData.title,
      description: formData.description,
      category_id: category_id, // Send as number, not string
      technologies: formData.technologies.split(',').map(t => t.trim()),
      github_link: formData.github_link || '',
      demo_link: formData.demo_link || '',
      document_path: formData.document_path || ''
      // DON'T send faculty_id - backend will get it from user token
    };

    console.log('Submitting project data:', projectData);

    const response = await fetch(`${API_URL}/projects`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`,
      },
      body: JSON.stringify(projectData),
    });

    const data = await response.json();
    console.log('Response:', response.status, data);

    if (!response.ok) {
      // Handle specific error cases
      if (response.status === 401) {
        // Token invalid or expired
        localStorage.removeItem('ucuToken');
        alert('Session expired. Please login again.');
        window.location.href = '/login';
        return;
      }
      
      if (response.status === 400 && data.details) {
        // Validation errors
        alert(`Validation error: ${data.details}`);
        return;
      }
      
      throw new Error(data.error || 'Failed to submit project');
    }

    alert('Project submitted successfully! It is now pending review.');
    resetForm();
    
    // Refresh user projects list
    await refreshUserProjects();
    
    // Call parent handler if exists
    if (onProjectSubmit) {
      onProjectSubmit(data.project);
    }
    
  } catch (error) {
    console.error('Submission error:', error);
    alert(error.message || 'Failed to submit project. Please check your connection and try again.');
  } finally {
    setLoading(false);
  }
};

  const resetForm = () => {
    setFormData({
      title: '',
      description: '',
      category: '',
      technologies: '',
      github_link: '',
      demo_link: '',
      document_path: ''
    });
    setShowSubmitForm(false);
  };

  const refreshUserProjects = async () => {
  try {
    const token = localStorage.getItem('ucuToken');
    if (!token) {
      console.error('No token found for fetching user projects');
      return;
    }

    const response = await fetch(`${API_URL}/projects/my-projects`, {
      headers: {
        'Authorization': `Bearer ${token}`,
      },
    });

    if (!response.ok) {
      if (response.status === 401) {
        localStorage.removeItem('ucuToken');
        window.location.href = '/login';
        return;
      }
      throw new Error('Failed to fetch projects');
    }

    const data = await response.json();
    setUserProjects(data);
    console.log('User projects refreshed:', data.length);
  } catch (error) {
    console.error('Error refreshing projects:', error);
  }
};

  const getDefaultImage = (category) => {
    const categoryImages = {
      'Web Application': 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=400&h=300&fit=crop',
      'Mobile Application': 'https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?w=400&h=300&fit=crop',
      'Data Science': 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=400&h=300&fit=crop',
      'Machine Learning': 'https://images.unsplash.com/photo-1555255707-c07966088b7b?w=400&h=300&fit=crop',
      'IoT': 'https://images.unsplash.com/photo-1558618666-fcd25856cd25?w=400&h=300&fit=crop',
      'Blockchain': 'https://images.unsplash.com/photo-1639762681485-074b7f938ba0?w=400&h=300&fit=crop',
      'Game Development': 'https://images.unsplash.com/photo-1542751371-adc38448a05e?w=400&h=300&fit=crop',
      'Other': 'https://images.unsplash.com/photo-1535223289827-42f1e9919769?w=400&h=300&fit=crop'
    };
    return categoryImages[category] || 'https://images.unsplash.com/photo-1535223289827-42f1e9919769?w=400&h=300&fit=crop';
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'pending':
        return <Clock className="status-icon pending" />;
      case 'approved':
        return <CheckCircle className="status-icon approved" />;
      case 'rejected':
        return <XCircle className="status-icon rejected" />;
      default:
        return null;
    }
  };

  const getStatusBadgeClass = (status) => {
    switch (status) {
      case 'pending':
        return 'status-badge pending';
      case 'approved':
        return 'status-badge approved';
      case 'rejected':
        return 'status-badge rejected';
      default:
        return 'status-badge default';
    }
  };

  const formatTechnologies = (technologies) => {
    if (Array.isArray(technologies)) {
      return technologies;
    }
    try {
      if (typeof technologies === 'string') {
        return JSON.parse(technologies);
      }
      return [];
    } catch {
      return [];
    }
  };

  const getProjectImage = (project) => {
    return getDefaultImage(project.category_name || project.category);
  };

  return (
    <div className="student-dashboard">
      {/* Header */}
      <header className="dashboard-header">
        <div className="header-container">
          <Link to="/" className="logo-link">
            <div className="logo-icon">
              <Lightbulb className="logo-svg" />
            </div>
            <div className="logo-text">
              <h1 className="logo-title">UCU Innovators Hub</h1>
              <p className="logo-subtitle">Student Dashboard</p>
            </div>
          </Link>
          <div className="header-actions">
            <div className="user-info">
              <p className="user-name">{user.name}</p>
              <p className="user-department">{user.department}</p>
            </div>
            <button
              onClick={onLogout}
              className="logout-btn"
            >
              <LogOut className="logout-icon" />
              <span className="logout-text">Logout</span>
            </button>
          </div>
        </div>
      </header>

      <div className="dashboard-container">
        {/* Welcome Section */}
        <div className="welcome-section">
          <h2 className="welcome-title">Welcome back, {user.name.split(' ')[0]}!</h2>
          <p className="welcome-subtitle">Manage your project submissions and track their approval status.</p>
        </div>

        {/* Stats */}
        <div className="stats-grid">
          <div className="stat-card">
            <div className="stat-content">
              <div className="stat-icon pending">
                <Clock className="stat-icon-svg" />
              </div>
              <div className="stat-text">
                <p className="stat-value">{pendingCount}</p>
                <p className="stat-label">Pending Review</p>
              </div>
            </div>
          </div>
          <div className="stat-card">
            <div className="stat-content">
              <div className="stat-icon approved">
                <CheckCircle className="stat-icon-svg" />
              </div>
              <div className="stat-text">
                <p className="stat-value">{approvedCount}</p>
                <p className="stat-label">Approved</p>
              </div>
            </div>
          </div>
          <div className="stat-card">
            <div className="stat-content">
              <div className="stat-icon rejected">
                <XCircle className="stat-icon-svg" />
              </div>
              <div className="stat-text">
                <p className="stat-value">{rejectedCount}</p>
                <p className="stat-label">Rejected</p>
              </div>
            </div>
          </div>
        </div>

        {/* Submit Project Button */}
        <div className="submit-button-container">
          <button
            onClick={() => setShowSubmitForm(!showSubmitForm)}
            className="submit-project-btn"
            disabled={loading}
          >
            <Plus className="btn-icon" />
            Submit New Project
          </button>
        </div>

        {/* Submit Form */}
        {showSubmitForm && (
          <div className="submit-form">
            <h3 className="form-title">Submit New Project</h3>
            <form onSubmit={handleSubmit} className="project-form">
              <div className="form-group">
                <label className="form-label">Project Title *</label>
                <input
                  type="text"
                  name="title"
                  value={formData.title}
                  onChange={handleChange}
                  required
                  placeholder="Enter your project title"
                  className="form-input"
                  disabled={loading}
                />
              </div>

              <div className="form-group">
                <label className="form-label">Description *</label>
                <textarea
                  name="description"
                  value={formData.description}
                  onChange={handleChange}
                  required
                  rows={4}
                  placeholder="Describe your project, its purpose, and key features"
                  className="form-textarea"
                  disabled={loading}
                />
              </div>

              <div className="form-grid">
                <div className="form-group">
                  <label className="form-label">Category *</label>
                  <select
                    name="category"
                    value={formData.category}
                    onChange={handleChange}
                    required
                    className="form-select"
                    disabled={loading}
                  >
                    <option value="">Select category</option>
                    {categories.map(cat => (
                      <option key={cat} value={cat}>{cat}</option>
                    ))}
                  </select>
                </div>

                <div className="form-group">
                  <label className="form-label">Technologies Used *</label>
                  <input
                    type="text"
                    name="technologies"
                    value={formData.technologies}
                    onChange={handleChange}
                    required
                    placeholder="e.g., React, Node.js, MongoDB (comma separated)"
                    className="form-input"
                    disabled={loading}
                  />
                </div>
              </div>

              <div className="form-grid">
                <div className="form-group">
                  <label className="form-label">
                    <LinkIcon className="label-icon" />
                    GitHub Repository Link
                  </label>
                  <input
                    type="url"
                    name="github_link"
                    value={formData.github_link}
                    onChange={handleChange}
                    placeholder="https://github.com/username/repo"
                    className="form-input"
                    disabled={loading}
                  />
                </div>

                <div className="form-group">
                  <label className="form-label">
                    <LinkIcon className="label-icon" />
                    Demo/Live Link
                  </label>
                  <input
                    type="url"
                    name="demo_link"
                    value={formData.demo_link}
                    onChange={handleChange}
                    placeholder="https://your-project-demo.com"
                    className="form-input"
                    disabled={loading}
                  />
                </div>
              </div>

              <div className="form-group">
                <label className="form-label">
                  <FileText className="label-icon" />
                  Project Document Link (Optional)
                </label>
                <input
                  type="url"
                  name="document_path"
                  value={formData.document_path}
                  onChange={handleChange}
                  placeholder="https://drive.google.com/... or document URL"
                  className="form-input"
                  disabled={loading}
                />
                <p className="input-hint">You can also upload documents directly using the file upload in the future</p>
              </div>

              <div className="form-actions">
                <button
                  type="submit"
                  className="btn-primary"
                  disabled={loading}
                >
                  {loading ? (
                    <>
                      <Loader className="button-loader" />
                      Submitting...
                    </>
                  ) : (
                    <>
                      <Upload className="btn-icon" />
                      Submit Project
                    </>
                  )}
                </button>
                <button
                  type="button"
                  onClick={resetForm}
                  className="btn-secondary"
                  disabled={loading}
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        )}

        {/* My Projects */}
        <div className="projects-section">
          <h3 className="section-title">My Projects ({userProjects.length})</h3>
          
          {userProjects.length === 0 ? (
            <div className="empty-projects">
              <p className="empty-text">You haven't submitted any projects yet.</p>
              <button
                onClick={() => setShowSubmitForm(true)}
                className="empty-action"
              >
                Submit your first project →
              </button>
            </div>
          ) : (
            <div className="projects-grid">
              {userProjects.map(project => (
                <div key={project.id} className="project-card">
                  {/* Project Image */}
                  <div className="project-image-container">
                    <img 
                      src={getProjectImage(project)} 
                      alt={project.title}
                      className="project-image"
                    />
                    <div className="project-status-overlay">
                      <span className={getStatusBadgeClass(project.status)}>
                        {project.status?.charAt(0).toUpperCase() + project.status?.slice(1) || 'Unknown'}
                      </span>
                    </div>
                  </div>

                  {/* Project Content */}
                  <div className="project-content">
                    <div className="project-header">
                      {getStatusIcon(project.status)}
                      <Link to={`/project/${project.id}`} className="project-link">
                        <h4 className="project-title">{project.title}</h4>
                      </Link>
                    </div>
                    
                    <p className="project-description">{project.description}</p>
                    
                    <div className="technologies-list">
                      {formatTechnologies(project.technologies).slice(0, 4).map((tech, index) => (
                        <span key={index} className="tech-tag">
                          {tech}
                        </span>
                      ))}
                      {formatTechnologies(project.technologies).length > 4 && (
                        <span className="tech-tag more">+{formatTechnologies(project.technologies).length - 4} more</span>
                      )}
                    </div>

                    <div className="project-meta">
                      <span className="category-badge">{project.category_name || project.category}</span>
                      <span className="faculty">{project.faculty_name || user.faculty}</span>
                    </div>

                    <div className="project-date">
                      Submitted: {project.created_at ? new Date(project.created_at).toLocaleDateString() : 'N/A'}
                    </div>

                    {project.feedback && (
                      <div className="feedback-section">
                        <p className="feedback-text">
                          <strong>Supervisor Feedback:</strong> {project.feedback}
                        </p>
                        {project.supervisor_name && (
                          <p className="feedback-author">— {project.supervisor_name}</p>
                        )}
                      </div>
                    )}

                    {(project.github_link || project.demo_link || project.document_path) && (
                      <div className="project-links">
                        {project.github_link && (
                          <a href={project.github_link} target="_blank" rel="noopener noreferrer" className="project-link">
                            <LinkIcon className="link-icon" />
                            GitHub
                          </a>
                        )}
                        {project.demo_link && (
                          <a href={project.demo_link} target="_blank" rel="noopener noreferrer" className="project-link">
                            <LinkIcon className="link-icon" />
                            Live Demo
                          </a>
                        )}
                        {project.document_path && (
                          <a href={project.document_path} target="_blank" rel="noopener noreferrer" className="project-link">
                            <FileText className="link-icon" />
                            Document
                          </a>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}