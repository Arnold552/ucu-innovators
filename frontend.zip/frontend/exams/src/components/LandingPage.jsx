import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Search, Filter, GraduationCap, Lightbulb, TrendingUp, Users, LogOut, User as UserIcon } from 'lucide-react';
import { ProjectCard } from './ProjectCard';
import './LandingPage.css';

export function LandingPage({ user, onLogout, projects }) {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedFaculty, setSelectedFaculty] = useState('all');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedYear, setSelectedYear] = useState('all');
  const [selectedTechnology, setSelectedTechnology] = useState('all');

  // Only show approved projects on public page
  const approvedProjects = projects.filter(p => p.status === 'approved');

  // Get unique values for filters
  const faculties = ['all', ...Array.from(new Set(approvedProjects.map(p => p.faculty)))];
  const categories = ['all', ...Array.from(new Set(approvedProjects.map(p => p.category)))];
  const years = ['all', ...Array.from(new Set(approvedProjects.map(p => p.year.toString())))];
  const allTechnologies = Array.from(new Set(approvedProjects.flatMap(p => p.technologies)));
  const technologies = ['all', ...allTechnologies];

  // Filter projects
  const filteredProjects = approvedProjects.filter(project => {
    const matchesSearch = project.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         project.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         project.submittedByName.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFaculty = selectedFaculty === 'all' || project.faculty === selectedFaculty;
    const matchesCategory = selectedCategory === 'all' || project.category === selectedCategory;
    const matchesYear = selectedYear === 'all' || project.year.toString() === selectedYear;
    const matchesTechnology = selectedTechnology === 'all' || project.technologies.includes(selectedTechnology);

    return matchesSearch && matchesFaculty && matchesCategory && matchesYear && matchesTechnology;
  });

  // Calculate stats
  const totalProjects = approvedProjects.length;
  const totalViews = approvedProjects.reduce((sum, p) => sum + p.views, 0);
  const uniqueDepartments = new Set(approvedProjects.map(p => p.department)).size;

  const handleDashboardClick = () => {
    if (user) {
      navigate(`/${user.role}`);
    }
  };

  return (
    <div className="landing-page">
      {/* Header */}
      <header className="landing-header">
        <div className="header-container">
          <div className="header-content">
            <div className="logo-section">
              <div className="logo-icon">
                <Lightbulb className="logo-svg" />
              </div>
              <div className="logo-text">
                <h1 className="logo-title">UCU Innovators Hub</h1>
                <p className="logo-subtitle">Uganda Christian University</p>
              </div>
            </div>
            <div className="header-actions">
              {user ? (
                <>
                  <button
                    onClick={handleDashboardClick}
                    className="btn btn-primary btn-sm"
                  >
                    <UserIcon className="btn-icon" />
                    <span className="btn-text">Dashboard</span>
                  </button>
                  <button
                    onClick={onLogout}
                    className="btn btn-outline btn-sm"
                  >
                    <LogOut className="btn-icon" />
                    <span className="btn-text">Logout</span>
                  </button>
                </>
              ) : (
                <>
                  <Link to="/login" className="auth-link">Login</Link>
                  <Link to="/register" className="btn btn-primary btn-sm">Register</Link>
                </>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="hero-section">
        <div className="hero-container">
          <div className="hero-content">
            <h2 className="hero-title">Discover Student Innovations</h2>
            <p className="hero-subtitle">
              Explore groundbreaking projects and research from Uganda Christian University students across all faculties
            </p>
            
            {/* Stats */}
            <div className="stats-grid">
              <div className="stat-card">
                <GraduationCap className="stat-icon" />
                <div className="stat-number">{totalProjects}</div>
                <div className="stat-label">Projects Published</div>
              </div>
              <div className="stat-card">
                <TrendingUp className="stat-icon" />
                <div className="stat-number">{totalViews.toLocaleString()}</div>
                <div className="stat-label">Total Views</div>
              </div>
              <div className="stat-card">
                <Users className="stat-icon" />
                <div className="stat-number">{uniqueDepartments}</div>
                <div className="stat-label">Departments</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Search and Filters */}
      <section className="filters-section">
        <div className="filters-container">
          <div className="filters-card">
            <div className="filters-header">
              <Filter className="filter-icon" />
              <h3 className="filters-title">Search & Filter Projects</h3>
            </div>

            <div className="filters-content">
              {/* Search Bar */}
              <div className="search-container">
                <Search className="search-icon" />
                <input
                  type="text"
                  placeholder="Search projects, students, or keywords..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="search-input"
                />
              </div>

              {/* Filters */}
              <div className="filters-grid">
                <select
                  value={selectedFaculty}
                  onChange={(e) => setSelectedFaculty(e.target.value)}
                  className="filter-select"
                >
                  {faculties.map(faculty => (
                    <option key={faculty} value={faculty}>
                      {faculty === 'all' ? 'All Faculties' : faculty}
                    </option>
                  ))}
                </select>

                <select
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="filter-select"
                >
                  {categories.map(category => (
                    <option key={category} value={category}>
                      {category === 'all' ? 'All Categories' : category}
                    </option>
                  ))}
                </select>

                <select
                  value={selectedYear}
                  onChange={(e) => setSelectedYear(e.target.value)}
                  className="filter-select"
                >
                  {years.map(year => (
                    <option key={year} value={year}>
                      {year === 'all' ? 'All Years' : year}
                    </option>
                  ))}
                </select>

                <select
                  value={selectedTechnology}
                  onChange={(e) => setSelectedTechnology(e.target.value)}
                  className="filter-select"
                >
                  {technologies.map(tech => (
                    <option key={tech} value={tech}>
                      {tech === 'all' ? 'All Technologies' : tech}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="results-count">
              Showing {filteredProjects.length} of {totalProjects} projects
            </div>
          </div>
        </div>
      </section>

      {/* Projects Grid */}
      <section className="projects-section">
        <div className="projects-container">
          {filteredProjects.length === 0 ? (
            <div className="empty-state">
              <p className="empty-text">No projects found matching your criteria.</p>
            </div>
          ) : (
            <div className="projects-grid">
              {filteredProjects.map(project => (
                <ProjectCard key={project.id} project={project} />
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Footer */}
      <footer className="landing-footer">
        <div className="footer-container">
          <p className="footer-text">
            © 2025 UCU Innovators Hub. Uganda Christian University. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
}