import { Link } from 'react-router-dom';
import { Eye, Heart, Calendar, User } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import './ProjectCard.css';

export function ProjectCard({ project }) {
  return (
    <Link to={`/project/${project.id}`} className="project-card-link">
      <div className="project-card">
        {/* Project Image */}
        <div className="project-image-container">
          {project.imageUrl ? (
            <ImageWithFallback
              src={project.imageUrl}
              alt={project.title}
              className="project-image"
            />
          ) : (
            <div className="project-image-fallback">
              <span className="fallback-text">No Image</span>
            </div>
          )}
        </div>

        {/* Project Content */}
        <div className="project-content">
          <div className="project-main">
            <h3 className="project-title">{project.title}</h3>
            <p className="project-description">{project.description}</p>

            {/* Category Badge */}
            <div className="category-container">
              <span className="category-badge">
                {project.category}
              </span>
            </div>

            {/* Technologies */}
            <div className="technologies-container">
              {project.technologies.slice(0, 3).map((tech, index) => (
                <span key={index} className="tech-tag">
                  {tech}
                </span>
              ))}
              {project.technologies.length > 3 && (
                <span className="tech-tag">
                  +{project.technologies.length - 3} more
                </span>
              )}
            </div>
          </div>

          {/* Metadata */}
          <div className="project-metadata">
            <div className="metadata-row">
              <div className="metadata-item">
                <User className="metadata-icon" />
                <span className="metadata-text">{project.submittedByName}</span>
              </div>
              <div className="metadata-item">
                <Calendar className="metadata-icon" />
                <span className="metadata-text">{project.year}</span>
              </div>
            </div>
            <div className="metadata-row">
              <div className="metadata-item">
                <Eye className="metadata-icon" />
                <span className="metadata-text">{project.views}</span>
              </div>
              <div className="metadata-item">
                <Heart className="metadata-icon" />
                <span className="metadata-text">{project.likes}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Link>
  );
}