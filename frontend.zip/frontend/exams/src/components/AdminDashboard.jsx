import { Link } from 'react-router-dom';
import { Lightbulb, LogOut, TrendingUp, FolderOpen, CheckCircle, Clock } from 'lucide-react';
import { BarChart, Bar, PieChart, Pie, Cell, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import './AdminDashboard.css';

export function AdminDashboard({ user, onLogout, projects }) {
  // Calculate statistics
  const totalProjects = projects.length;
  const pendingProjects = projects.filter(p => p.status === 'pending').length;
  const approvedProjects = projects.filter(p => p.status === 'approved').length;
  const rejectedProjects = projects.filter(p => p.status === 'rejected').length;
  const approvalRate = totalProjects > 0 ? ((approvedProjects / totalProjects) * 100).toFixed(1) : 0;

  // Projects per faculty
  const projectsByFaculty = projects.reduce((acc, project) => {
    acc[project.faculty] = (acc[project.faculty] || 0) + 1;
    return acc;
  }, {});

  const facultyData = Object.entries(projectsByFaculty).map(([name, value]) => ({
    name: name.split(' ').slice(0, 2).join(' '),
    value,
    fullName: name
  }));

  // Projects by category
  const projectsByCategory = projects.reduce((acc, project) => {
    acc[project.category] = (acc[project.category] || 0) + 1;
    return acc;
  }, {});

  const categoryData = Object.entries(projectsByCategory).map(([name, value]) => ({
    name,
    projects: value
  }));

  // Status distribution
  const statusData = [
    { name: 'Approved', value: approvedProjects, color: '#10b981' },
    { name: 'Pending', value: pendingProjects, color: '#f59e0b' },
    { name: 'Rejected', value: rejectedProjects, color: '#ef4444' }
  ].filter(item => item.value > 0);

  // Technology trends
  const techCount = projects.reduce((acc, project) => {
    project.technologies.forEach(tech => {
      acc[tech] = (acc[tech] || 0) + 1;
    });
    return acc;
  }, {});

  const topTechnologies = Object.entries(techCount)
    .sort(([, a], [, b]) => b - a)
    .slice(0, 8)
    .map(([name, count]) => ({ name, count }));

  // Projects over time
  const projectsByYear = projects.reduce((acc, project) => {
    acc[project.year] = (acc[project.year] || 0) + 1;
    return acc;
  }, {});

  const yearData = Object.entries(projectsByYear)
    .sort(([a], [b]) => Number(a) - Number(b))
    .map(([year, count]) => ({ year, projects: count }));

  const COLORS = ['#8b5cf6', '#ec4899', '#06b6d4', '#f59e0b', '#10b981', '#6366f1', '#f97316', '#14b8a6'];

  return (
    <div className="admin-dashboard">
      {/* Header */}
      <header className="admin-header">
        <div className="admin-header-content">
          <Link to="/" className="admin-logo">
            <div className="logo-icon">
              <Lightbulb className="logo-icon-svg" />
            </div>
            <div className="logo-text">
              <h1 className="logo-title">UCU Innovators Hub</h1>
              <p className="logo-subtitle">Admin Dashboard</p>
            </div>
          </Link>
          <div className="admin-user-info">
            <div className="user-details">
              <p className="user-name">{user.name}</p>
              <p className="user-role">Administrator</p>
            </div>
            <button
              onClick={onLogout}
              className="logout-btn"
            >
              <LogOut className="logout-icon" />
              <span className="logout-text">Logout</span>
            </button>
          </div>
        </div>
      </header>

      <div className="admin-container">
        {/* Welcome Section */}
        <div className="welcome-section">
          <h2 className="welcome-title">Analytics Dashboard</h2>
          <p className="welcome-subtitle">Track project submissions, approval rates, and innovation trends across UCU.</p>
        </div>

        {/* Key Metrics */}
        <div className="metrics-grid">
          <div className="metric-card">
            <div className="metric-content">
              <div className="metric-icon purple">
                <FolderOpen className="metric-icon-svg" />
              </div>
              <div className="metric-text">
                <p className="metric-value">{totalProjects}</p>
                <p className="metric-label">Total Projects</p>
              </div>
            </div>
          </div>

          <div className="metric-card">
            <div className="metric-content">
              <div className="metric-icon green">
                <CheckCircle className="metric-icon-svg" />
              </div>
              <div className="metric-text">
                <p className="metric-value">{approvedProjects}</p>
                <p className="metric-label">Approved</p>
              </div>
            </div>
          </div>

          <div className="metric-card">
            <div className="metric-content">
              <div className="metric-icon yellow">
                <Clock className="metric-icon-svg" />
              </div>
              <div className="metric-text">
                <p className="metric-value">{pendingProjects}</p>
                <p className="metric-label">Pending</p>
              </div>
            </div>
          </div>

          <div className="metric-card">
            <div className="metric-content">
              <div className="metric-icon blue">
                <TrendingUp className="metric-icon-svg" />
              </div>
              <div className="metric-text">
                <p className="metric-value">{approvalRate}%</p>
                <p className="metric-label">Approval Rate</p>
              </div>
            </div>
          </div>
        </div>

        {/* Charts Row 1 */}
        <div className="charts-row">
          {/* Projects by Faculty */}
          <div className="chart-card">
            <h3 className="chart-title">Projects by Faculty</h3>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={facultyData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" angle={-45} textAnchor="end" height={80} />
                <YAxis />
                <Tooltip content={({ active, payload }) => {
                  if (active && payload && payload[0]) {
                    return (
                      <div className="chart-tooltip">
                        <p className="tooltip-title">{payload[0].payload.fullName}</p>
                        <p className="tooltip-value">{payload[0].value} projects</p>
                      </div>
                    );
                  }
                  return null;
                }} />
                <Bar dataKey="value" fill="#8b5cf6" />
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Status Distribution */}
          <div className="chart-card">
            <h3 className="chart-title">Project Status Distribution</h3>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={statusData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} (${(percent * 100).toFixed(0)}%)`}
                  outerRadius={100}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {statusData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Charts Row 2 */}
        <div className="charts-row">
          {/* Projects by Category */}
          <div className="chart-card">
            <h3 className="chart-title">Projects by Category</h3>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={categoryData} layout="horizontal">
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis type="number" />
                <YAxis dataKey="name" type="category" width={120} />
                <Tooltip />
                <Bar dataKey="projects" fill="#ec4899" />
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Projects Over Time */}
          <div className="chart-card">
            <h3 className="chart-title">Projects Over Time</h3>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={yearData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="year" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="projects" stroke="#8b5cf6" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Technology Trends */}
        <div className="chart-card full-width">
          <h3 className="chart-title">Top Technologies Used</h3>
          <ResponsiveContainer width="100%" height={350}>
            <BarChart data={topTechnologies}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" angle={-45} textAnchor="end" height={100} />
              <YAxis />
              <Tooltip />
              <Bar dataKey="count" fill="#06b6d4">
                {topTechnologies.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Recent Activity */}
        <div className="chart-card">
          <h3 className="chart-title">Recent Projects</h3>
          <div className="recent-projects">
            {projects
              .sort((a, b) => new Date(b.submittedDate).getTime() - new Date(a.submittedDate).getTime())
              .slice(0, 5)
              .map(project => (
                <div key={project.id} className="project-item">
                  <div className="project-info">
                    <Link to={`/project/${project.id}`} className="project-link">
                      <p className="project-title">{project.title}</p>
                    </Link>
                    <p className="project-meta">
                      {project.submittedByName} • {project.faculty} • {project.submittedDate}
                    </p>
                  </div>
                  <span className={`status-badge status-${project.status}`}>
                    {project.status.charAt(0).toUpperCase() + project.status.slice(1)}
                  </span>
                </div>
              ))}
          </div>
        </div>

        {/* Department Stats */}
        <div className="stats-grid">
          <div className="stat-card">
            <h4 className="stat-title">Unique Departments</h4>
            <p className="stat-value">
              {new Set(projects.map(p => p.department)).size}
            </p>
          </div>
          <div className="stat-card">
            <h4 className="stat-title">Unique Students</h4>
            <p className="stat-value">
              {new Set(projects.map(p => p.submittedBy)).size}
            </p>
          </div>
          <div className="stat-card">
            <h4 className="stat-title">Total Views</h4>
            <p className="stat-value">
              {projects.reduce((sum, p) => sum + p.views, 0).toLocaleString()}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}