export const API_URL = import.meta.env.VITE_API_URL;

// Example fetch
export const fetchProjects = async () => {
  const res = await fetch(`${API_URL}/projects`);
  return res.json();
};