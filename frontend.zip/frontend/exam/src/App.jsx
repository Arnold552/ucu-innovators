import { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { LandingPage } from './components/LandingPage';
import { LoginPage } from './components/LoginPage';
import { RegisterPage } from './components/RegisterPage';
import { StudentDashboard } from './components/StudentDashboard';
import { SupervisorDashboard } from './components/SupervisorDashboard';
import { AdminDashboard } from './components/AdminDashboard';
import { ProjectDetailPage } from './components/ProjectDetailPage';
import { ProtectedRoute } from './components/ProtectedRoute';

import './App.css';

function App() {
  const [user, setUser] = useState(null);
  const [projects, setProjects] = useState([]);

  // Initialize with mock data
  useEffect(() => {
    // Check for stored user
    const storedUser = localStorage.getItem('ucuUser');
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }

    // Initialize mock projects
    const mockProjects = [
      {
        id: '1',
        title: 'Smart Campus Navigation System',
        description: 'An AI-powered mobile application that helps students and visitors navigate the UCU campus using augmented reality and real-time location services.',
        category: 'Mobile Application',
        faculty: 'Science and Technology',
        department: 'Computer Science',
        technologies: ['React Native', 'TensorFlow', 'Google Maps API', 'Firebase'],
        year: 2024,
        githubLink: 'https://github.com/example/campus-nav',
        status: 'approved',
        submittedBy: 'std1',
        submittedByName: 'Sarah Nakato',
        supervisorName: 'Dr. James Okello',
        submittedDate: '2024-11-15',
        reviewDate: '2024-11-20',
        imageUrl: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&q=80',
        views: 234,
        likes: 45,
        comments: []
      },
      {
        id: '2',
        title: 'Agricultural Market Price Prediction System',
        description: 'Machine learning model that predicts crop prices in Ugandan markets to help farmers make informed decisions about when to sell their produce.',
        category: 'Data Science',
        faculty: 'Science and Technology',
        department: 'Computer Science',
        technologies: ['Python', 'Scikit-learn', 'Django', 'PostgreSQL'],
        year: 2024,
        githubLink: 'https://github.com/example/agri-predict',
        status: 'approved',
        submittedBy: 'std2',
        submittedByName: 'David Mugisha',
        supervisorName: 'Prof. Grace Nambooze',
        submittedDate: '2024-10-28',
        reviewDate: '2024-11-05',
        imageUrl: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&q=80',
        views: 189,
        likes: 38,
        comments: []
      },
      {
        id: '3',
        title: 'E-Health Records Management for Rural Clinics',
        description: 'A web-based system for managing patient records in rural health centers with offline capabilities and data synchronization.',
        category: 'Web Application',
        faculty: 'Science and Technology',
        department: 'Information Technology',
        technologies: ['React', 'Node.js', 'MongoDB', 'PWA'],
        year: 2024,
        githubLink: 'https://github.com/example/ehealth',
        status: 'pending',
        submittedBy: 'std3',
        submittedByName: 'Mary Auma',
        submittedDate: '2024-11-25',
        imageUrl: 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=800&q=80',
        views: 45,
        likes: 12,
        comments: []
      },
      {
        id: '4',
        title: 'Smart Library Management System',
        description: 'Automated library system with book recommendation engine, RFID integration, and predictive analytics for book availability.',
        category: 'Web Application',
        faculty: 'Science and Technology',
        department: 'Computer Science',
        technologies: ['Vue.js', 'Laravel', 'MySQL', 'Redis'],
        year: 2024,
        status: 'approved',
        submittedBy: 'std4',
        submittedByName: 'Emmanuel Okoth',
        supervisorName: 'Dr. Ruth Nabwire',
        submittedDate: '2024-09-10',
        reviewDate: '2024-09-18',
        imageUrl: 'https://images.unsplash.com/photo-1507842217343-583bb7270b66?w=800&q=80',
        views: 312,
        likes: 67,
        comments: []
      },
      {
        id: '5',
        title: 'Traffic Flow Optimization for Kampala',
        description: 'IoT and AI-based solution for real-time traffic monitoring and optimization to reduce congestion in Kampala city.',
        category: 'IoT',
        faculty: 'Engineering',
        department: 'Electrical Engineering',
        technologies: ['Arduino', 'Raspberry Pi', 'TensorFlow', 'React'],
        year: 2023,
        status: 'approved',
        submittedBy: 'std5',
        submittedByName: 'Patrick Opio',
        supervisorName: 'Eng. Francis Odongo',
        submittedDate: '2023-12-05',
        reviewDate: '2023-12-15',
        imageUrl: 'https://images.unsplash.com/photo-1449965408869-eaa3f722e40d?w=800&q=80',
        views: 567,
        likes: 98,
        comments: []
      },
      {
        id: '6',
        title: 'Student Mental Health Support Platform',
        description: 'Anonymous platform connecting students with counseling resources, peer support groups, and mental health tracking tools.',
        category: 'Web Application',
        faculty: 'Social Sciences',
        department: 'Psychology',
        technologies: ['React', 'Express', 'MongoDB', 'Socket.io'],
        year: 2024,
        status: 'pending',
        submittedBy: 'std6',
        submittedByName: 'Rebecca Nansubuga',
        submittedDate: '2024-11-28',
        imageUrl: 'https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?w=800&q=80',
        views: 23,
        likes: 8,
        comments: []
      }
    ];

    const storedProjects = localStorage.getItem('ucuProjects');
    if (!storedProjects) {
      localStorage.setItem('ucuProjects', JSON.stringify(mockProjects));
      setProjects(mockProjects);
    } else {
      setProjects(JSON.parse(storedProjects));
    }
  }, []);

  const handleLogin = (loggedInUser) => {
    setUser(loggedInUser);
    localStorage.setItem('ucuUser', JSON.stringify(loggedInUser));
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem('ucuUser');
  };

  const handleRegister = (newUser) => {
    setUser(newUser);
    localStorage.setItem('ucuUser', JSON.stringify(newUser));
  };

  const handleProjectSubmit = (project) => {
    const newProject = {
      ...project,
      id: Date.now().toString(),
      submittedDate: new Date().toISOString().split('T')[0],
      views: 0,
      likes: 0,
      comments: []
    };
    
    const updatedProjects = [...projects, newProject];
    setProjects(updatedProjects);
    localStorage.setItem('ucuProjects', JSON.stringify(updatedProjects));
  };

  const handleProjectUpdate = (updatedProject) => {
    const updatedProjects = projects.map(p => 
      p.id === updatedProject.id ? updatedProject : p
    );
    setProjects(updatedProjects);
    localStorage.setItem('ucuProjects', JSON.stringify(updatedProjects));
  };

  const handleProjectReview = (projectId, status, comments) => {
    const updatedProjects = projects.map(p => 
      p.id === projectId 
        ? { 
            ...p, 
            status, 
            reviewComments: comments,
            reviewDate: new Date().toISOString().split('T')[0],
            supervisorName: user?.name 
          } 
        : p
    );
    setProjects(updatedProjects);
    localStorage.setItem('ucuProjects', JSON.stringify(updatedProjects));
  };

  const handleAddComment = (projectId, content) => {
    if (!user) return;

    const comment = {
      id: Date.now().toString(),
      projectId,
      userId: user.id,
      userName: user.name,
      userRole: user.role,
      content,
      date: new Date().toISOString()
    };

    const updatedProjects = projects.map(p => 
      p.id === projectId 
        ? { ...p, comments: [...p.comments, comment] } 
        : p
    );
    setProjects(updatedProjects);
    localStorage.setItem('ucuProjects', JSON.stringify(updatedProjects));
  };

  return (
    <Router>
      <Routes>
        <Route path="/" element={<LandingPage user={user} onLogout={handleLogout} projects={projects} />} />
        <Route path="/login" element={user ? <Navigate to={`/${user.role}`} /> : <LoginPage onLogin={handleLogin} />} />
        <Route path="/register" element={user ? <Navigate to={`/${user.role}`} /> : <RegisterPage onRegister={handleRegister} />} />
        <Route path="/project/:id" element={<ProjectDetailPage user={user} onLogout={handleLogout} projects={projects} onAddComment={handleAddComment} onUpdateProject={handleProjectUpdate} />} />
        
        <Route
          path="/student"
          element={
            <ProtectedRoute user={user} allowedRoles={['student']}>
              <StudentDashboard user={user} onLogout={handleLogout} projects={projects} onProjectSubmit={handleProjectSubmit} />
            </ProtectedRoute>
          }
        />
        
        <Route
          path="/supervisor"
          element={
            <ProtectedRoute user={user} allowedRoles={['supervisor']}>
              <SupervisorDashboard user={user} onLogout={handleLogout} projects={projects} onProjectReview={handleProjectReview} />
            </ProtectedRoute>
          }
        />
        
        <Route
          path="/admin"
          element={
            <ProtectedRoute user={user} allowedRoles={['admin']}>
              <AdminDashboard user={user} onLogout={handleLogout} projects={projects} />
            </ProtectedRoute>
          }
        />
      </Routes>
    </Router>
  );
}

export default App;